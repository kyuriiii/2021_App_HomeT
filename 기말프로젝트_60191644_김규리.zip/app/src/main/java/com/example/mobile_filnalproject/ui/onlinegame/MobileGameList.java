package com.example.mobile_filnalproject.ui.onlinegame;
import android.graphics.drawable.Drawable;

public class MobileGameList {
    String name;
    Drawable image;

    public Drawable getImage() { return image; }
    public void setImage(Drawable image) { this.image = image; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}